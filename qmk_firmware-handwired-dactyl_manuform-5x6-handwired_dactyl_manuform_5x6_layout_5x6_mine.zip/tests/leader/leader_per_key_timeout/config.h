#pragma once

#include "test_common.h"

#define LEADER_PER_KEY_TIMING
